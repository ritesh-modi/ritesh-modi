# 01 — Context Synthesis

**Meridian Industrial Services — Quotation-to-Issue BPR**
Stage 1 of 5: read and synthesise only. No analysis, no improvement suggestions.

---

## 1. Restatement

Meridian Industrial Services, a ~1,400-staff industrial equipment servicing company operating across India and South-East Asia, runs a quotation-to-issue process for its planned maintenance contract line (~70% of revenue). The process is triggered when an RFQ arrives, usually by email to a shared inbox and occasionally via the customer portal. A sales coordinator logs it into the CRM, after which it waits in an unassigned queue until the once-daily assignment run. An account manager reviews it and decides whether a site survey is needed — in current practice, a survey is requested in almost all cases. After a scheduling wait, a field engineer attends site and takes notes on paper, then types those notes up, usually the following day. A technical author converts the notes into a scope of work, which then queues at the pricing desk; procurement returns current parts pricing and a pricing analyst builds the price from the rate card plus parts. The quotation waits for regional manager approval, which is required on every quotation regardless of value, and quotations above Rs 15 lakh additionally require Head of Service approval. A proposal writer then assembles the document from a Word template, re-keying the scope and price; the sales coordinator QA-checks it; and it is held for the twice-weekly send batch before being sent to the customer. Known pain centres on customer complaints about wait time, the pricing desk bottleneck (two analysts covering all regions), double handling of survey notes, and scope/price mismatches from re-keying. The process operates under non-negotiable constraints: safety-critical scopes must be signed by a qualified engineer (regulatory), customer pricing may not be placed in tools not approved by IT Security, the CRM cannot be replaced this financial year, and the rate card is owned by Finance and changes quarterly. A second pricing analyst was added in 2024; elapsed time improved by under a day and the queue re-formed within two months.

---

## 2. Numbers given

### Tagged as supplied

- 180 quotation requests per month. **[MEASURED]**
- Median elapsed time, RFQ received to quotation sent: 11 working days. **[MEASURED]**
- Total active work per quotation: 390 minutes (6h 30m). **[ESTIMATED]**
- Win rate on issued quotations: 22%. **[MEASURED]**
- 34% of quotations go through at least one internal revision cycle before issue. **[MEASURED]**
- 9% of RFQs withdrawn by customer or awarded elsewhere before issue. **[MEASURED]**

### Numbers supplied

Reproduced as given, untagged.

**Organisation**
- ~1,400 staff
- Planned maintenance contracts ~70% of revenue

**Step timings**

| Step | Activity | Duration |
|---|---|---|
| 1 | Log RFQ into CRM | 15 min |
| 2 | Unassigned queue (assignments run once daily) | 1 day |
| 3 | Account manager review | 20 min |
| 4 | Wait for survey scheduling | 3 days |
| 5 | Field engineer on site | 90 min |
| 6 | Engineer types up notes | 1 day |
| 7 | Technical author scope of work | 75 min |
| 8 | Pricing desk queue | 2 days |
| 9 | Procurement returns parts pricing | 1 day |
| 10 | Pricing analyst builds price | 60 min |
| 11 | Wait for regional manager approval | 1.5 days |
| 12 | Regional manager approves | 10 min |
| 13 | Head of Service approval above Rs 15 lakh (about 34% of quotations) | 1 day |
| 14 | Proposal writer assembles document | 90 min |
| 15 | Sales coordinator QA check | 25 min |
| 16 | Twice-weekly send batch hold | 0.5 day |
| 17 | Sent to customer | 5 min |

**Thresholds and rates**
- Head of Service approval threshold: Rs 15 lakh
- Fully loaded hourly rates (Rs): Sales coordinator 450 | Account manager 1,200 | Field engineer 900 | Technical author 700 | Pricing analyst 800 | Regional manager 2,000 | Head of Service 3,200 | Proposal writer 650

**Capacity and prior intervention**
- Pricing desk staffing: two analysts covering all regions
- Second pricing analyst added in 2024; elapsed time improved by under a day; queue re-formed within two months
- Competitor quoting time reported by customers: within a week

---

## 3. NOT STATED

- Average or median quotation value; total value of quotations issued per month or per year; revenue or margin attached to won work.
- Cost of the process per quotation, or in total, expressed in money.
- Distribution of elapsed time — only the median is given; no mean, spread, percentiles, or worst case.
- Distribution of active work time across the steps as actually observed (the 390-minute figure is estimated and its build-up is not reconciled to the step times).
- How many revision cycles the 34% figure represents, what triggers them, how long each adds, and which step they return to.
- Whether the 9% withdrawal rate is concentrated at a particular elapsed-time threshold or process stage.
- Win rate broken down by value band, region, customer type, or elapsed time.
- Proportion of RFQs arriving by email versus customer portal.
- What "almost all cases" means numerically for survey requests, and what proportion of surveys are genuinely necessary.
- What proportion of scopes are safety-critical and therefore subject to the regulatory sign-off constraint.
- Rework or error rate arising from the re-keying scope/price mismatches, and the cost or delay consequence when one is caught or missed.
- Headcount and capacity (FTE, available hours) for each role in the process other than the two pricing analysts.
- Utilisation rates, backlog size, or queue lengths at each wait point.
- Seasonality or variability in the 180/month volume.
- Whether volume is growing, flat, or declining.
- Number of regions, and whether the process differs by region or country.
- Rejection rate at regional manager and Head of Service approval steps, and what happens to a rejected quotation.
- Existing systems in use beyond the CRM and Word (e.g. pricing tools, survey tools, document management, portal capability), and what the CRM can and cannot do.
- IT Security's approved tool list, and what approval for a new tool would involve or cost.
- Budget, timeframe, and appetite for change; who owns the process and who sponsors the reengineering.
- Any SLA or contractual commitment to customers on quotation turnaround.
- Competitor turnaround as verified fact rather than customer report.
- Union, employment, or contractual constraints on changing roles or ways of working.
- Whether reactive repair work shares any of these steps or staff.
- Interventions attempted other than the 2024 addition of a second pricing analyst.
