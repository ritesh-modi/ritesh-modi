
## 1. The context pack

```
ORGANISATION
Meridian Industrial Services. Mid-size industrial equipment servicing
company, ~1,400 staff, operating across India and South-East Asia. We
service and maintain industrial cooling and process equipment. Two
revenue lines: planned maintenance contracts (~70% of revenue) and
reactive repair work. This process concerns planned maintenance
contracts only.

THE PROCESS: quotation to issue
Trigger: a request for quotation (RFQ) arrives, usually by email to a
shared inbox, occasionally through the customer portal.

Steps as they run today:
 1. Sales coordinator logs the RFQ into the CRM.                  [15 min]
 2. Waits in an unassigned queue; assignments run once daily.      [1 day]
 3. Account manager reviews and decides whether a site survey is
    required. Current practice: a survey is requested in almost
    all cases.                                                     [20 min]
 4. Waits for survey scheduling.                                  [3 days]
 5. Field engineer attends site, takes notes on paper.            [90 min]
 6. Engineer types the notes up, usually next day.                 [1 day]
 7. Technical author converts survey notes into a scope of work.   [75 min]
 8. Waits in the pricing desk queue.                              [2 days]
 9. Procurement returns current parts pricing.                     [1 day]
10. Pricing analyst builds the price from rate card + parts.       [60 min]
11. Waits for regional manager approval.                         [1.5 days]
12. Regional manager approves. Every quotation requires this
    regardless of value.                                           [10 min]
13. Quotations above Rs 15 lakh also require Head of Service.
    This applies to about 34% of quotations.                        [1 day]
14. Proposal writer assembles the document from a Word template,
    re-keying the scope and price.                                 [90 min]
15. Sales coordinator QA-checks it.                                [25 min]
16. Held for the twice-weekly send batch.                        [0.5 day]
17. Sent to the customer.                                           [5 min]

VOLUMES AND TIMINGS
- 180 quotation requests per month.                          [MEASURED]
- Median elapsed time, RFQ received to quotation sent:
  11 working days.                                           [MEASURED]
- Total active work per quotation: 390 minutes (6h 30m).     [ESTIMATED]
- Win rate on issued quotations: 22%.                        [MEASURED]
- 34% of quotations go through at least one internal revision
  cycle before issue.                                        [MEASURED]
- 9% of RFQs are withdrawn by the customer, or awarded
  elsewhere, before we have issued anything.                 [MEASURED]

FULLY LOADED HOURLY RATES (Rs)
Sales coordinator 450 | Account manager 1,200 | Field engineer 900
Technical author 700 | Pricing analyst 800 | Regional manager 2,000
Head of Service 3,200 | Proposal writer 650

KNOWN PAIN
- Customers complain about the wait; several have said our
  competitors quote within a week.
- Sales say the 9% withdrawal rate is mostly impatience.
- The pricing desk is a recognised bottleneck; two analysts
  cover all regions.
- Engineers dislike the double handling of survey notes.
- Proposal writers report frequent scope/price mismatches
  caused by re-keying.

CONSTRAINTS
- Safety-critical scopes must be signed by a qualified engineer.
  Non-negotiable, regulatory.
- Customer pricing is commercially sensitive; it may not be
  placed in any tool not approved by IT Security.
- The CRM cannot be replaced this financial year.
- Rate card is owned by Finance and changes quarterly.

WHAT WE HAVE ALREADY TRIED
- Added a second pricing analyst in 2024. Elapsed time improved
  by under a day; the queue re-formed within two months.
```
---
